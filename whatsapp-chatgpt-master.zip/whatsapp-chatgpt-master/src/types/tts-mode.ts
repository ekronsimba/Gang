export enum TTSMode {
	SpeechAPI = "speech-api",
	AWSPolly = "aws-polly"
}
