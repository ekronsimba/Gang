export enum AWSPollyEngine {
	Standard = "standard",
	Neural = "neural"
}
