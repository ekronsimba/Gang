export enum dalleConfigType {
	size = "size"
}

export enum dalleImageSize {
	"256x256" = "256x256",
	"512x512" = "512x512",
	"1024x1024" = "1024x1024"
}
