export enum TranscriptionMode {
	Local = "local",
	SpeechAPI = "speech-api",
	WhisperAPI = "whisper-api",
	OpenAI = "openai"
}
