# Disclaimer

The operations performed by this bot are not free. You will be charged by OpenAI for each request you make.

This bot uses Puppeteer to run a real instance of Whatsapp Web to avoid getting blocked.

NOTE: We can't guarantee that you won't be blocked using this method, although it does work.

WhatsApp does not allow bots or unofficial clients on its platform, so this should not be considered completely safe.
