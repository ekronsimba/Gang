# Docker

Make sure to edit the `docker-compose.yml` file and set your own variables there.

```sh
sudo docker-compose up
```
