# Send messages to yourself

You can also use the bot to send messages to yourself.

Use this WhatsApp link: https://wa.me/your_phone_number.

Replace `your_phone_number` with your phone number, including the country code. (e.g. +11234567890)

The URL above will take you to your own chat window.
